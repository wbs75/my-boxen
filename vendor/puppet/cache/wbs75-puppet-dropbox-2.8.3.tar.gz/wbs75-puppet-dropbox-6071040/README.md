# Dropbox Puppet Module for Boxen
[![Build
Status](https://travis-ci.org/boxen/puppet-dropbox.png?branch=master)](https://travis-ci.org/boxen/puppet-dropbox)

Install [Dropbox](http://www.dropbox.com), an easy way to share files
and folders on Mac OS X.

## Usage

```puppet
include dropbox
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
